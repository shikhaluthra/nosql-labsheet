// STUDENTDB MONGODB CRUD PRACTICALS
// Name used in sample data: Shikha
// Run with: mongosh < StudentDB_All_Questions.js
// This is a sequential demonstration. Run against a test MongoDB instance.
// The script intentionally drops StudentDB in Q20, then recreates it in Q21.

print("\n========== Q1. CREATE AND VERIFY StudentDB ==========");
use("StudentDB");
db.createCollection("Students"); // A database is persisted after its first collection/document is created.
print("Current database: " + db.getName());
print("Collections after creation:");
printjson(db.getCollectionNames());

print("\n========== Q2. CREATE COLLECTIONS ==========");
db.createCollection("Faculty");
db.createCollection("Courses");
print("Collections:");
printjson(db.getCollectionNames());

print("\n========== Q3. INSERT ONE STUDENT ==========");
db.Students.insertOne({
  RollNumber: 101,
  Name: "Shikha",
  Department: "Computer Science",
  Semester: 5,
  CGPA: 8.7
});
printjson(db.Students.findOne({ RollNumber: 101 }));

print("\n========== Q4. INSERT MULTIPLE STUDENTS ==========");
db.Students.insertMany([
  { RollNumber: 102, Name: "Aarav", Department: "Information Technology", Semester: 5, CGPA: 8.2 },
  { RollNumber: 103, Name: "Priya", Department: "Computer Science", Semester: 4, CGPA: 9.1 },
  { RollNumber: 104, Name: "Rohan", Department: "Electronics", Semester: 5, CGPA: 7.9 },
  { RollNumber: 105, Name: "Meera", Department: "Computer Science", Semester: 4, CGPA: 8.5 }
]);
print("Total students after insertion: " + db.Students.countDocuments());

print("\n========== Q5. DISPLAY ALL STUDENTS ==========");
db.Students.find().forEach(printjson);

print("\n========== Q6. FIND BY ROLL NUMBER ==========");
db.Students.find({ RollNumber: 103 }).forEach(printjson);

print("\n========== Q7. FIND BY DEPARTMENT ==========");
db.Students.find({ Department: "Computer Science" }).forEach(printjson);

print("\n========== Q8. FIELD PROJECTION ==========");
db.Students.find({}, { _id: 0, Name: 1, Department: 1 }).forEach(printjson);

print("\n========== Q9. UPDATE ONE STUDENT'S DEPARTMENT ==========");
db.Students.updateOne(
  { RollNumber: 102 },
  { $set: { Department: "Computer Science" } }
);
printjson(db.Students.findOne({ RollNumber: 102 }));

print("\n========== Q10. UPDATE MANY STUDENTS' SEMESTER ==========");
db.Students.updateMany(
  { Department: "Computer Science" },
  { $set: { Semester: 6 } }
);
print("Modified documents: " + db.Students.countDocuments({ Department: "Computer Science", Semester: 6 }));

print("\n========== Q11. REPLACE ONE DOCUMENT ==========");
db.Students.replaceOne(
  { RollNumber: 104 },
  { RollNumber: 104, Name: "Rohan", Department: "Electronics", Semester: 6, CGPA: 8.0, Email: "rohan@example.com" }
);
printjson(db.Students.findOne({ RollNumber: 104 }));

print("\n========== Q12. ADD EMAIL FIELD TO ALL STUDENTS ==========");
db.Students.updateMany(
  {},
  [{ $set: { Email: { $concat: [{ $toString: "$RollNumber" }, "@student.example.com"] } } }]
);
db.Students.find({}, { _id: 0, RollNumber: 1, Email: 1 }).forEach(printjson);

print("\n========== Q13. REMOVE AN EXISTING FIELD ==========");
// Add a temporary field first so the $unset operation can be demonstrated clearly.
db.Students.updateMany({}, { $set: { TemporaryNote: "Remove this field" } });
db.Students.updateMany({}, { $unset: { TemporaryNote: "" } });
print("Documents still containing TemporaryNote: " + db.Students.countDocuments({ TemporaryNote: { $exists: true } }));

print("\n========== Q14. DELETE ONE STUDENT BY ROLL NUMBER ==========");
db.Students.deleteOne({ RollNumber: 103 });
print("Student 103 remaining: " + db.Students.countDocuments({ RollNumber: 103 }));

print("\n========== Q15. DELETE MANY STUDENTS BY CONDITION ==========");
db.Students.deleteMany({ Department: "Electronics" });
print("Electronics students remaining: " + db.Students.countDocuments({ Department: "Electronics" }));

print("\n========== Q16. COUNT ALL STUDENTS ==========");
print("Total student documents: " + db.Students.countDocuments());

print("\n========== Q17. RENAME Students TO StudentDetails ==========");
db.Students.renameCollection("StudentDetails");
print("Collections after rename:");
printjson(db.getCollectionNames());
print("StudentDetails document count: " + db.StudentDetails.countDocuments());

print("\n========== Q18. CREATE Departments AND INSERT SAMPLE DATA ==========");
db.createCollection("Departments");
db.Departments.insertMany([
  { DepartmentID: 1, DepartmentName: "Computer Science", HOD: "Dr. Sharma" },
  { DepartmentID: 2, DepartmentName: "Information Technology", HOD: "Dr. Verma" },
  { DepartmentID: 3, DepartmentName: "Electronics", HOD: "Dr. Gupta" }
]);
db.Departments.find().forEach(printjson);

print("\n========== Q19. DROP Departments COLLECTION ==========");
db.Departments.drop();
print("Departments collection exists: " + db.getCollectionNames().includes("Departments"));

print("\n========== Q20. DROP StudentDB DATABASE ==========");
print("Database before drop: " + db.getName());
print("dropDatabase() result:");
printjson(db.dropDatabase());
print("StudentDB has been dropped. (It may not appear in show dbs.)");

print("\n========== Q21. RECREATE StudentDB AND INSERT SAMPLE DATA ==========");
use("StudentDB");
db.createCollection("Students");
db.Students.insertMany([
  { RollNumber: 201, Name: "Shikha", Department: "Computer Science", Semester: 5, CGPA: 8.8, Email: "shikha@example.com" },
  { RollNumber: 202, Name: "Aarav", Department: "Information Technology", Semester: 4, CGPA: 8.3, Email: "aarav@example.com" }
]);
print("Recreated database: " + db.getName());
db.Students.find().forEach(printjson);

print("\n========== Q22. CRUD USING MONGODB COMPASS ==========");
print("Compass steps are provided in README.md. Repeat insert, find, update and delete using the GUI.");

print("\n========== Q23. SHELL AND COMPASS ==========");
print("Shell: type commands in mongosh. Compass: connect to the same server and use the GUI.");
print("Both tools manage the same MongoDB data when connected to the same deployment.");

print("\n========== Q24. MONGODB AND SQL ==========");
print("Examples and comparison are provided in README.md and Lab_Report.md.");

print("\n========== Q25. LAB REPORT ==========");
print("See Lab_Report.md for objectives, commands, expected outputs, observations and conclusion.");
print("\n========== PRACTICALS COMPLETED ==========");
