# Laboratory Report: MongoDB Database and CRUD Operations

**Student Name:** Shikha  
**Database Name:** StudentDB  
**Collection:** Students  
**Experiment:** Database, collection and CRUD operations using MongoDB Shell and MongoDB Compass

## 1. Aim
To create and manage a MongoDB database and collections, perform insert, read, update and delete (CRUD) operations, and compare MongoDB operations with equivalent SQL commands.

## 2. Objectives
- Create and verify the `StudentDB` database.
- Create collections and insert single and multiple student documents.
- Retrieve documents using filters and projection.
- Update and replace documents and fields.
- Delete selected and multiple documents.
- Count documents, rename and drop collections, and drop/recreate a database.
- Perform equivalent operations using MongoDB Compass.
- Compare MongoDB CRUD commands with SQL statements.

## 3. Software Requirements
- MongoDB Community Server or another MongoDB deployment
- MongoDB Shell (`mongosh`)
- MongoDB Compass
- Windows/Linux/macOS computer

## 4. Theory
MongoDB is a NoSQL, document-oriented database. It stores records as BSON documents inside collections. A database contains collections, and a collection contains documents. CRUD stands for Create, Read, Update and Delete. MongoDB Shell provides a command-line interface, while MongoDB Compass provides a graphical interface for managing the same database.

## 5. Procedure and Commands

The complete executable sequence for Questions 1–21 is in `StudentDB_All_Questions.js`. The main commands used are:

```javascript
use("StudentDB");
db.createCollection("Students");
db.createCollection("Faculty");
db.createCollection("Courses");

db.Students.insertOne({
  RollNumber: 101,
  Name: "Shikha",
  Department: "Computer Science",
  Semester: 5,
  CGPA: 8.7
});

db.Students.insertMany([
  { RollNumber: 102, Name: "Aarav", Department: "Information Technology", Semester: 5, CGPA: 8.2 },
  { RollNumber: 103, Name: "Priya", Department: "Computer Science", Semester: 4, CGPA: 9.1 }
]);

db.Students.find();
db.Students.find({ RollNumber: 103 });
db.Students.find({ Department: "Computer Science" });
db.Students.find({}, { _id: 0, Name: 1, Department: 1 });

db.Students.updateOne(
  { RollNumber: 102 },
  { $set: { Department: "Computer Science" } }
);

db.Students.updateMany(
  { Department: "Computer Science" },
  { $set: { Semester: 6 } }
);

db.Students.replaceOne(
  { RollNumber: 104 },
  { RollNumber: 104, Name: "Rohan", Department: "Electronics", Semester: 6, CGPA: 8.0 }
);

db.Students.updateMany({}, { $set: { Email: "shikha@example.com" } });
db.Students.updateMany({}, { $unset: { TemporaryNote: "" } });

db.Students.deleteOne({ RollNumber: 103 });
db.Students.deleteMany({ Department: "Electronics" });
db.Students.countDocuments();

db.Students.renameCollection("StudentDetails");
db.createCollection("Departments");
db.Departments.insertOne({
  DepartmentID: 1,
  DepartmentName: "Computer Science",
  HOD: "Dr. Sharma"
});
db.Departments.drop();
db.dropDatabase();
```

After dropping the database, it was recreated and sample data was inserted again in Question 21. Refer to the script for the complete exact sequence and all 25 question sections.

## 6. Outputs
The expected results are listed question-wise in `Outputs.txt`. Important results include:
- `StudentDB` is created and contains `Students`, `Faculty` and `Courses`.
- Five student records exist after the initial insert operations.
- Filter and projection queries display the requested records/fields.
- Update commands modify matching documents.
- Delete commands remove matching records.
- `countDocuments()` displays the number of remaining records.
- `Students` is renamed to `StudentDetails`.
- `Departments` is dropped successfully.
- `StudentDB` is dropped and then recreated with sample data.



## 7. MongoDB Compass Procedure
1. Connect Compass to the same MongoDB server.
2. Create `StudentDB` and the `Students` collection.
3. Add the sample student document using **Add Data → Insert Document**.
4. Add multiple documents and use the filter and project fields to retrieve records.
5. Edit documents to perform updates.
6. Use document/collection actions to delete records, rename collections and drop collections.
7. Compare the Compass view with the results from `mongosh`.

## 8. MongoDB and SQL Comparison
MongoDB stores flexible BSON documents in collections, whereas SQL databases generally store rows in tables. MongoDB uses methods such as `insertOne()`, `find()`, `updateOne()` and `deleteOne()`. SQL uses `INSERT`, `SELECT`, `UPDATE` and `DELETE`. Both systems support CRUD operations, but their data models and query syntax are different.

## 9. Observations
- A MongoDB database becomes visible after a collection or document is created.
- A collection can store multiple documents.
- Filters retrieve only matching documents.
- Projection displays only selected fields.
- `$set` adds or changes a field, while `$unset` removes a field.
- `updateOne()` changes one matching document; `updateMany()` can change many.
- `deleteOne()` removes one matching document; `deleteMany()` removes all matching documents.
- Compass and Shell show the same data when connected to the same MongoDB deployment.

## 10. Conclusion
The experiment demonstrates how to create and manage a MongoDB database and collections and how to perform CRUD operations using MongoDB Shell and MongoDB Compass. It also shows the basic differences between MongoDB and SQL. The practical objectives were covered through the commands and procedures provided.


