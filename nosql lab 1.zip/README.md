# MongoDB StudentDB Lab Practicals (Questions 1–25)

**Student name in sample records: Shikha**

## Files
- `StudentDB_All_Questions.js` — complete MongoDB Shell script for the practical sequence.
- `Outputs.txt` — representative output guide for every question.
- `Lab_Report.md` — ready-to-edit laboratory report with objectives, commands, observations and conclusion.

## Requirements
1. Install MongoDB Community Server and MongoDB Shell (`mongosh`), or use an accessible MongoDB deployment.
2. Alternatively, install MongoDB Compass and connect to your MongoDB server.
3. Use a test database only. **Question 20 drops the entire `StudentDB` database.**

## Run the Shell script
Open a terminal in this folder and run:

```bash
mongosh < StudentDB_All_Questions.js
```

You can also open `mongosh` and paste/run the commands section by section. The script is sequential; run it on a clean test database to get the intended sequence.

## Compass instructions (Questions 22–23)
1. Open MongoDB Compass and connect to the same MongoDB deployment used by `mongosh`.
2. Click **Create Database**. Enter `StudentDB` as the database and `Students` as the first collection.
3. Open `StudentDB`. Use **Create Collection** to add `Faculty` and `Courses`.
4. Open `Students` → **Add Data** → **Insert Document**. Enter a document like:

```json
{
  "RollNumber": 101,
  "Name": "Shikha",
  "Department": "Computer Science",
  "Semester": 5,
  "CGPA": 8.7
}
```

5. For multiple records, choose **Add Data** → **Insert Many** (or insert documents one at a time, depending on Compass version).
6. Use the **Documents** tab and filter box for queries, e.g. `{ "RollNumber": 101 }` or `{ "Department": "Computer Science" }`.
7. Use **Project** to show selected fields, e.g. `{ "Name": 1, "Department": 1, "_id": 0 }`.
8. Use the document pencil/edit controls to update a record. Use the collection's **Aggregations** or document actions where appropriate for bulk updates/deletes; Compass menu labels can vary by version.
9. Use the collection options menu to rename or drop a collection. Use the database options menu to drop a database.
10. Compare the documents shown in Compass with `mongosh` queries. If both are connected to the same deployment, changes made in one are visible in the other after refresh.

## SQL equivalents (Question 24)

| Task | MongoDB | SQL |
|---|---|---|
| Create database | `use StudentDB` then create a collection/document | `CREATE DATABASE StudentDB;` |
| Create collection/table | `db.createCollection("Students")` | `CREATE TABLE Students (...);` |
| Insert one | `insertOne({...})` | `INSERT INTO Students VALUES (...);` |
| Insert many | `insertMany([...])` | Multiple `INSERT` statements |
| Read all | `find({})` | `SELECT * FROM Students;` |
| Filter | `find({RollNumber: 101})` | `SELECT * FROM Students WHERE RollNumber=101;` |
| Projection | `find({}, {Name:1, Department:1, _id:0})` | `SELECT Name, Department FROM Students;` |
| Update one | `updateOne(filter, {$set: ...})` | `UPDATE Students SET ... WHERE ...;` |
| Update many | `updateMany(filter, {$set: ...})` | `UPDATE Students SET ... WHERE ...;` |
| Delete one | `deleteOne(filter)` | `DELETE FROM Students WHERE ...;` |
| Delete many | `deleteMany(filter)` | `DELETE FROM Students WHERE ...;` |
| Count | `countDocuments({})` | `SELECT COUNT(*) FROM Students;` |
| Drop collection | `db.Departments.drop()` | `DROP TABLE Departments;` |
| Drop database | `db.dropDatabase()` | `DROP DATABASE StudentDB;` |

### Main differences
- MongoDB stores data as flexible BSON documents in collections; SQL databases commonly store structured rows in tables.
- MongoDB documents can have different fields; relational tables normally follow a defined schema.
- MongoDB uses JSON-like query objects and operators; SQL uses statements such as `SELECT`, `INSERT`, `UPDATE` and `DELETE`.
- Relationships can be represented through embedded documents or references in MongoDB; relational databases commonly use foreign keys and joins.
- Both support CRUD operations, indexing, validation and transactions, although implementation and syntax differ.

## Notes
- `use StudentDB` switches the shell's current database, but an empty database is not permanently listed until data or a collection is created.
- The script creates `Students` during Q1 so the database is physically created and verifiable.
- The script uses a temporary `TemporaryNote` field in Q13, then removes it with `$unset`, so the field-removal operation is visible without deleting a useful student field.
- Q20 is destructive. Back up anything important before running the script.
